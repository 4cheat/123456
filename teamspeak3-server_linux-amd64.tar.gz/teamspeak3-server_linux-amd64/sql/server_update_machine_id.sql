update servers set server_machine_id= :server_machine_id: where server_id=:server_id:;
